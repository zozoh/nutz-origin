package com.nutzam.web;

import org.nutz.web.WebLauncher;

public class NutzamLauncher extends WebLauncher {

    public static void main(String[] args) {
        WebLauncher.start(args);
    }
    
}