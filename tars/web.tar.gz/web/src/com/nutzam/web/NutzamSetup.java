package com.nutzam.web;

import org.nutz.mvc.NutConfig;
import org.nutz.mvc.Setup;

public class NutzamSetup implements Setup {

    @Override
    public void init(NutConfig nc) {}

    @Override
    public void destroy(NutConfig nc) {}

}
