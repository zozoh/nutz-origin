package com.nutzam.web;

import org.nutz.web.WebConfig;

public class NutzamConfig extends WebConfig {

    public NutzamConfig(String path) {
        super(path);
    }

}
