var ioc = {

	conf : {
		type : 'com.nutzam.web.NutzamConfig',
		args : [ 'web.properties' ]
	}

};